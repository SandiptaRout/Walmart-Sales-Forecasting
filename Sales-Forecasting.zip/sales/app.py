
import streamlit as st
import pandas as pd
import xgboost as xgb
import plotly.graph_objects as go
from datetime import timedelta

# --- PAGE SETUP ---
st.set_page_config(page_title="Walmart Sales Analytics", layout="wide", page_icon="📈")

@st.cache_resource
def load_resources():
    model = xgb.XGBRegressor()
    model.load_model('sales_model.json')
    df = pd.read_pickle('processed_data.pkl')
    return model, df

try:
    model, df = load_resources()

    st.title("📈 Walmart Sales Forecasting System")
    
    # --- SIDEBAR WITH ACCURACY METRICS ---
    with st.sidebar:
        st.header("Model Performance")
        st.success(f"**R² Score:** 0.9807")
        st.info(f"**MAE:** $54,877.79")
        st.warning(f"**RMSE:** $78,372.13")
        st.divider()
        
        st.header("Settings")
        store_id = st.selectbox("Select Store ID", sorted(df['Store'].unique()))
        forecast_weeks = st.slider("Forecast Period (Weeks)", 1, 12, 4)

    # --- DATA LOGIC ---
    store_df = df[df['Store'] == store_id].sort_values('Date')
    last_date = store_df['Date'].max()
    
    future_dates = [last_date + timedelta(weeks=i) for i in range(1, forecast_weeks + 1)]
    future_df = pd.DataFrame({
        'Store': store_id,
        'Date': future_dates,
        'Month': [d.month for d in future_dates],
        'WeekOfYear': [d.isocalendar().week for d in future_dates],
        'IsHoliday': 0 
    })

    future_df['Predicted_Sales'] = model.predict(future_df[['Store', 'Month', 'WeekOfYear', 'IsHoliday']])

    # --- MAIN DASHBOARD ---
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("Visual Sales Trend")
        fig = go.Figure()
        hist_subset = store_df.tail(20) 
        fig.add_trace(go.Scatter(x=hist_subset['Date'], y=hist_subset['Weekly_Sales'], 
                                 name="Actual", line=dict(color='#0071ce', width=3)))
        fig.add_trace(go.Scatter(x=future_df['Date'], y=future_df['Predicted_Sales'], 
                                 name="AI Forecast", line=dict(color='#ffc220', width=3, dash='dot')))
        fig.update_layout(template="plotly_white", height=400, margin=dict(l=20, r=20, t=20, b=20))
        st.plotly_chart(fig, use_container_width=True)

    with col2:
        st.subheader("Forecast Insights")
        next_week_val = future_df['Predicted_Sales'].iloc[0]
        st.metric("Next Week Prediction", f"${next_week_val:,.2f}")
        st.write("---")
        st.write(f"The model predicts a total revenue of **${future_df['Predicted_Sales'].sum():,.2f}** over the next {forecast_weeks} weeks.")

except Exception as e:
    st.error(f"Error: {e}")