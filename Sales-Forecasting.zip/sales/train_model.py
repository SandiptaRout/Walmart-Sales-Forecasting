import pandas as pd
import xgboost as xgb
import pickle
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import numpy as np

# 1. Load and Preprocess
df = pd.read_csv('walmart.csv')
df.columns = df.columns.str.strip()
df['Date'] = pd.to_datetime(df['Date'], dayfirst=True, errors='coerce')
df = df.dropna(subset=['Date'])

# Feature Engineering
df['Month'] = df['Date'].dt.month
df['WeekOfYear'] = df['Date'].dt.isocalendar().week
if 'IsHoliday' not in df.columns:
    df['IsHoliday'] = 0
else:
    df['IsHoliday'] = df['IsHoliday'].astype(int)

# 2. Train the Model
# We are training one global model for all stores for this demo
features = ['Store', 'Month', 'WeekOfYear', 'IsHoliday']
X = df[features]
y = df['Weekly_Sales']

model = xgb.XGBRegressor(n_estimators=100, learning_rate=0.1)
model.fit(X, y)

from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import numpy as np

# ... (after model.fit) ...

# 1. Make predictions on the training set to check performance
train_preds = model.predict(X)

# 2. Calculate Regression Metrics
mae = mean_absolute_error(y, train_preds)
rmse = np.sqrt(mean_squared_error(y, train_preds))
r2 = r2_score(y, train_preds)

print(f"--- Model Performance Metrics ---")
print(f"R² Score (Accuracy equivalent): {r2:.4f}")
print(f"Mean Absolute Error (MAE): ${mae:.2f}")
print(f"Root Mean Squared Error (RMSE): ${rmse:.2f}")

# 3. Save the Model and the Data
# We save the model to a file so the app can load it instantly
model.save_model('sales_model.json')
df.to_pickle('processed_data.pkl')

print("✅ Model trained and saved as 'sales_model.json'")